use alt + z if you're on Windows/Linux
use option + z if you're on Mac
it will toggle wrap the text and you would be able to see everything properly

First of all we learnt how java program works.
we write our java program in Java Source File(.java) which is technically written in english using java syntax.
then
we compile that java source file using javac Main.java
where Main is the name of the class where our public static void main method is.
then 
we got a Java Class File(.class) which is technically bytecode and still our machine cannot understand it, though JVM(Java Virtual Machine) can understand Bytecode easily and hence it act as a bridge between java class file (bytecode) and machine(machine code) , eventually making JAVA PLATFORM INDEPENDENT.

after that we installed some VS Code Extensions which makes our Java Coding efficient and easy.
we installed three extensions:
        1. Test Runner for Java by Microsoft
        2. Debugger for Java by Microsoft
        3. Language Support for Java(TM) by Red Hat

Java Code Snippet Feature is used for avoiding writing the same boiler-plate code again-and-again. i've provided it's respective code java.json you just have copy-and-paste that's all, i hope it's not much of a rocket science.

BUT STILL. . . 

if you're having any error regarding running Java using extensions or Java Code Snippet Feature, you're free to contact me on instagram @kodewithkopi , though your patience is appreciated

THANK YOU!!!