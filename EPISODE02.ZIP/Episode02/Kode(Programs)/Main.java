public class Main
{
    public static void main(String[] args)
    {
        // Java Course: KodeWithKopi -> java code of "How Java Program Works? + Setting Up Visual Studio Code Environment for Java"
        /* 
        we installed three extensions:
        1. Test Runner for Java by Microsoft
        2. Debugger for Java by Microsoft
        3. Language Support for Java(TM) by Red Hat
        */
        System.out.println("Hello, World!");
        System.out.println("This is a Java Course");
    }
}