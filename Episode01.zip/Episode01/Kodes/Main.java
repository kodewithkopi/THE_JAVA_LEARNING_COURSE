public class Main
{
    public static void main(String[] args)
    {
	// THIS IS A SINGLE-LINE COMMENT
	/* THIS
		IS
		A
	  MULTI-
	   LINE	
        COMMENT
	*/ 
        System.out.println("Hello World!");
    }
}