use alt + z if you're on Windows/Linux
use option + z if you're on Mac
it will toggle wrap the text and you would be able to see everything properly

you can compile your java source file or your java program using 
"javac Main.java"

you can run your java class file or your compiled java program or your java bytecode using
"java Main"

if you're using Notepad and Command Prompt irrespective of OS let it be mac, windows or even linux
1. open your terminal(windows)/shell(mac/linux)
2. use cd and paste the path of your folder where you have saved the program file
3. if it consists of spaces in name of the folder/s then put your path inside double like this
WINDOWS
 if your folders does not have any space in their name cd C:\Users\KodeWithKopi\TheJavaLearningCourse\Episode01\Kodes
 if your folders does have space in their name cd "C:\Users\Kode With Kopi\The Java Learning Course\Episode 01\Kodes"

MAC/LINUX
if your folders does not have any space in their name cd C:/Users/KodeWithKopi/TheJavaLearningCourse/Episode01/Kodes
if your folders does have space in their name cd "C:/Users/Kode With Kopi/The Java Learning Course/Episode 01/Kodes"

and then compile or run

if you're using VS CODE (which i haven't introduced yet) then you can open terminal inside vs code using
WINDOWS/LINUX: ctrl + ` 
MAC: cmd + `

and then same as the terminal/shell for changing the directory if it's not proper.

if you're having any error regarding compiling or running, you're free to contact me on instagram @kodewithkopi , though your patience is appreciated

THANK YOU!!!