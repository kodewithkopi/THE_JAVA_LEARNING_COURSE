SORRY EVERYONE!

i am still working on this section known as "DORA THE EXPLORER" which is intended to introduce with the things you would in later, but i want to make it in an interactive way so i might take some time to refine it.

I really Appreciate Your Patience.
THANK YOU !