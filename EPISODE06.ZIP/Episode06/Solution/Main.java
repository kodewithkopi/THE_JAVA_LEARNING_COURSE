import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;


public class Main
{
    public static void main(String[] args)
    {
        System.out.println("\nTHIS IS A CALCULATOR\n");
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader myReader = new BufferedReader(isr);
        double num1 = 0.0d , num2 = 0.0d ;
        try
        {
            System.out.print("Enter First Number: ");
            num1 = Double.parseDouble(myReader.readLine());

            System.out.print("Enter Second Number: ");
            num2 = Double.parseDouble(myReader.readLine());
        }
        catch(Exception ex)
        {
            System.out.println("Error: "+ex.getMessage());
        }

        System.out.println("\nFirst Number is "+ num1);
        System.out.println("Second Number is "+num2 +"\n");

        
        double 
        addition = num1 + num2 ,
        subtraction = num1 - num2 ,
        product = num1 * num2 ,
        quotient = num1 / num2 ,
        remainder = num1 % num2 ,
        squareNum1 =  num1 * num1 ,
        squareNum2 = num2*num2 ,
        cubeNum1 = num1*num1*num1 ,
        cubeNum2 = num2*num2*num2 ;

        System.out.println("The Addition of "+ num1 + " and " + num2 + " is " + addition);
        System.out.println("The Subtraction of "+ num1 + " and " + num2 + " is " + subtraction);
        System.out.println("The Product of "+ num1 + " and " + num2 + " is " + product);
        System.out.println("The Quotient of "+ num1 + " and " + num2 + " is " + quotient);
        System.out.println("The Remainder of "+ num1 + " and " + num2 + " is " + remainder);

        System.out.println("Square of "+num1+" is " + squareNum1);
        System.out.println("Square of "+num2+" is " + squareNum2);
        System.out.println("Cube of "+num1+" is " + cubeNum1);
        System.out.println("Cube of "+num2+" is " + cubeNum2+"\n");
        
        // Typecasting
        // char v = 'O' ;
        // int f = (int) v ; 
        // System.out.println(f);

        System.out.println("SOLUTION OF P2\n");
        boolean cond1 = 'K' == 'O' ;
        boolean cond2 = 'K' != 'O' ;
        boolean cond3 = 'K' > 'O' ;
        boolean cond4 = 'K' >= 'O' ;
        boolean cond5 = 'K' < 'O' ;
        boolean cond6 = 'K' <= 'O' ;

        System.out.println("'K' == 'O' is "+ cond1);
        System.out.println("'K' != 'O' is "+ cond2);
        System.out.println("'K'  > 'O' is "+ cond3);
        System.out.println("'K' >= 'O' is "+ cond4);
        System.out.println("'K'  < 'O' is "+ cond5);
        System.out.println("'K' <= 'O' is "+ cond6);

        System.out.println("\nSOLUTION OF P3\n");

        boolean trueCond = true , falseCond = false;

        System.out.println("THE WORKING OF LOGICAL AND OPERATOR");
        System.out.println("cond1\tcond2\tAND(&&)");
        System.out.println("------------------------------");
        System.out.println(trueCond + "\t" + trueCond+ "\t" + (trueCond && trueCond));
        System.out.println(trueCond + "\t" + falseCond+ "\t" + (trueCond && falseCond));
        System.out.println(falseCond + "\t" + trueCond+ "\t" + (falseCond && trueCond));
        System.out.println(falseCond + "\t" + falseCond+ "\t" + (falseCond && falseCond));
        
        System.out.println("\nTHE WORKING OF LOGICAL OR OPERATOR");
        System.out.println("cond1\tcond2\tOR(||)");
        System.out.println("------------------------------");
        System.out.println(trueCond + "\t" + trueCond+ "\t" + (trueCond || trueCond));
        System.out.println(trueCond + "\t" + falseCond+ "\t" + (trueCond || falseCond));
        System.out.println(falseCond + "\t" + trueCond+ "\t" + (falseCond || trueCond));
        System.out.println(falseCond + "\t" + falseCond+ "\t" + (falseCond || falseCond));

        System.out.println("\nThe Working of LOGICAL NOT OPERATOR");
        System.out.println("cond1\tNOT(!)");
        System.out.println("----------------------------------");
        System.out.println(trueCond + "\t" + !(trueCond));
        System.out.println(falseCond + "\t"  + !(falseCond));
        System.out.println();
    }
}