public class Main
{
    public static void main(String[] args)
    {
        // PRACTICE SET SOLVING SESSION OF PRACTICE SET 01 : practice set of "Introduction to Java + Installing JDK , VS Code and Writing & Running our first java program"

       /*  // Solution for try changing Hello World! to 
        1. my name is [Your name here].
        2. What is Your Favourite Game?\nCricket.
        3. Stay Away From Me\tYou.
        */

        System.out.println("Hello World!");
        System.out.println("my name is Kopi.");
        System.out.println("What is Your Favourite Game?\nCricket.");
        System.out.println("Stay Away From Me\tYou.");
        


        /*
         second thing i want you to do is replace System.out.println() --> System.out.print() and use three System.out.print() with write those three sentences and check what happens

         */

        System.out.print("Hello World!");
        System.out.print("my name is Kopi.");
        System.out.print("What is Your Favourite Game?\nCricket.");
        System.out.print("Stay Away From Me\tYou.");
       
        
    }
}